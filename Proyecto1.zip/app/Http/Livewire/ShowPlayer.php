<?php

namespace App\Http\Livewire;

use App\Models\Player;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class ShowPlayer extends Component
{
    use WithPagination  ;
    use WithFileUploads;

    public $campo='id', $orden='desc';
    public $isOpen=false, $isOpenShow=false;
    public Player $player;
    public $image;

    protected $listeners=['renderizarVista'=>'render'];
    protected $rules=[
        'player.titulo'=>'',
        'player.contenido'=>['required', 'string', 'min:10'],
        'player.status'=>['required'],
        'image'=>['nullable', 'image', 'max:1024']
    ];

    public function mount(){
        $this->player=new Player;
    }

    public function render()
    {
        $players = Player::where('team_id', auth()->user()->id)
        ->orderBy($this->campo, $this->orden)->paginate(5);
        
        return view('livewire.show-user-posts', compact('posts'));
    }

    public function ordenarPor($campo){
        if($campo==$this->campo){
            $this->orden = ($this->orden=='desc') ? 'asc' : 'desc';
        }
        else
            $this->campo=$campo;
    }

    public function borrar(Player $player){
        //1.- Borro el archivo de imagen
        Storage::delete($player->image);
        //Borro el player
        $player->delete();
        $this->emit('borrar', 'Registro Borrado');

    }
    public function editar(Player $player){
        $this->player=$player;
        $this->isOpen=true;

    }
    public function update(){
        $this->validate([
            'player.titulo'=>['required', 'string', 'min:3', 'unique:posts,titulo,'.$this->player->id]
        ]);
        //Queremos editar el registro
        if($this->image){
            //he subido una imagen
            //1.- Borro la imagen antigua
            Storage::delete($this->player->image);
            $imagenNueva = $this->image->store('posts');
            $this->player->image = $imagenNueva;
        }
        $this->player->save();
        $this->emit('info', "Registro Actualizado.");
        $this->reset(['isOpen', 'image']);


    }
    
    public function show(Player $player){
        $this->player=$player;
        $this->isOpenShow=true;
    }

    
}
