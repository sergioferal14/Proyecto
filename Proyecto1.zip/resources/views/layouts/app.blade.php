<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">


    <!-- Styles -->
    <link rel="stylesheet" href="{{ mix('css/app.css') }}">

    <!-- BootStrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Slick -->

    @livewireStyles

    <!-- Scripts -->
    <script src="{{ mix('js/app.js') }}" defer></script>

    <!-- Tailwind -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Sweet Alert -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        .heading {
            text-align: center !important;
            font-size: 30px !important;
            font:bold !important;
            margin-bottom: 50px !important;
        }

        .row {
            display: flex !important;
            flex-direction: row !important;
            justify-content: space-around !important;
            flex-flow: wrap !important;
        }

        .card {
            border-radius: 8px;
            border-width: 4px;
            border-color: #1a202c;
            box-shadow: 0 2px 2px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            margin: 20px;
            
            text-align: center;
            transition: all 0.25s;
            background-color: white;
            transition: 0.3s !important;
        }

        .card-header {
            text-align: center !important;
            padding: 60px 10px !important;
            background-image: url('storage/fondo-escudos.jpeg') !important;
            background-repeat: no-repeat;
            background-size: cover;
            background-size: 100% 100%;
            color: #fff !important;
        }

        .card-body {
            padding: 30px 20px !important;
            text-align: center !important;
            font-size: 18px !important;
        }

        .card-body .btn {
            display: block !important;
            color: #fff !important;
            margin-left: auto;
            margin-right: auto;
            text-align: center !important;
            background:darkcyan;
            margin-top: 30px !important;
            text-decoration: none !important;
            padding: 5px 5px !important;
            width: 50%;
        }
        
        .card-body .btns {
            display: block !important;
            color: #fff !important;
            text-align: center !important;
            margin-top: 30px !important;
            text-decoration: none !important;
            padding: 5px 5px !important;
           
        }

        .card:hover {
            transform: scale(1.05) !important;
            box-shadow: 0 0 40px -10px rgba(0, 0, 0, 0.25) !important;
        }

        

    </style>

</head>

<body class="font-sans antialiased bg-green-600">

    <div class="min-h-screen ">
        @livewire('navigation-menu')

        <!-- Page Heading -->
        @if (isset($header))
            <header class="bg-white shadow">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    {{ $header }}
                </div>
            </header>
        @endif

        <!-- Page Content -->
        <main>
            {{ $slot }}
        </main>
    </div>

    @stack('modals')

    @livewireScripts

    <script>
        Livewire.on("alerta", function(txt) {
            Swal.fire({
                icon: 'success',
                title: txt,
                showConfirmButton: false,
                timer: 1500
            })
        })
        Livewire.on('info', function(txt) {
            Swal.fire({
                icon: 'warning',
                title: txt,
                showConfirmButton: true,
            })
        });
        Livewire.on('borrar', function(txt) {
            Swal.fire({
                icon: 'error',
                title: txt,
                showConfirmButton: true,
            })
        });
    </script>
    <footer class="text-center lg:text-left bg-gray-900 text-white">
        <div class="flex justify-center items-center lg:justify-between p-6 border-b border-gray-300">
          <div class="mr-3 lg:block">
            <span>
              <div class="">
                <h6 class="uppercase font-semibold mb-4 flex justify-center md:justify-start">
                  <span class=" bg-white rounded text-black px-1">Contacto</span>
                </h6>
                <p class="flex items-center justify-center md:justify-start mb-4" style="white-space:nowrap;">
                  <span class="mr-3">
                    <i class="fa-solid fa-house"></i>
                    Almeria, Al 04007, Es
                  </span>
                  <span class="mr-3">
                    <i class="fa-solid fa-envelope"></i>
                    futbolmaster@gmail.com
                  </span>
                  <p>
                    <span class="mr-3">
                    <i class="fa-solid fa-phone"></i>
                    + 34 15 21 65
                  </span>
      
                  <span class="mr-3">
                    <i class="fa-solid fa-print"></i>
                    + 34 950 25 75 53
                  </span>
                  </p>
                  
                </p>
              </div>
            </span>
          </div>
          <div class="text-center p-4" style="white-space:nowrap;">
            <span>© 2021 Copyright:</span>
            <p class="text-white font-semibold">The site's content is the Copyright © Fútbol Master.</p>
            <p class="text-white font-semibold">Futbol Mater All Rights Reserved.</p>
          </div>
          <div class="flex justify-center">
            <a href="#!" class="mr-6 text-white">
              <i class="fa-brands fa-facebook"></i>
            </a>
            <a href="#!" class="mr-6 text-white">
              <i class="fa-brands fa-twitter"></i>
            </a>
            <a href="#!" class="mr-6 text-white">
              <i class="fa-brands fa-instagram"></i>
            </a>
            <a href="#!" class="mr-6 text-white">
              <i class="fa-brands fa-linkedin-in"></i>
            </a>
          </div>
        </div>
      </footer>
</body>

</html>
